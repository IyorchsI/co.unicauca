package co.unicauca.factory.domain.service;

import java.util.List;

import co.unicauca.factory.domain.entity.Medida;

public interface IMedidaService {
	public List<Medida> findAll();
	public Medida findById(Long id);
	public Medida create(Medida medida);
	public Medida update(Long id, Medida medida);
	public void deleteById(Long id);
}
