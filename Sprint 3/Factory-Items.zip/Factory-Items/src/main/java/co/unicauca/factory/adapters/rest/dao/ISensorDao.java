package co.unicauca.factory.adapters.rest.dao;

import org.springframework.data.repository.CrudRepository;

import co.unicauca.factory.domain.entity.Sensor;

public interface ISensorDao extends CrudRepository<Sensor, Long> {

}
