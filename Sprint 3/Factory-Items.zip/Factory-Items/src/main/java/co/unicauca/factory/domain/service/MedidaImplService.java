package co.unicauca.factory.domain.service;

import java.util.List;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import co.unicauca.factory.adapters.rest.dao.IMedidaDao;
import co.unicauca.factory.domain.entity.Medida;
@Service
public class MedidaImplService implements IMedidaService {

	@Autowired
	private IMedidaDao medidaDao;
	@Override
	@Transactional(readOnly = true) 
	public List<Medida> findAll() {
		return (List<Medida>) medidaDao.findAll();
	}

	@Override
	public Medida findById(Long id) {
		Medida medida = medidaDao.findById(id).orElse(null);
		return medida;
	}

	@Override
	@Transactional
	public Medida create(Medida medida) {
		return medidaDao.save(medida);
	}

	@Override
	@Transactional
	public Medida update(Long id, Medida medida) {
		Medida med = this.findById(id);
		med.setRadio(medida.getRadio());
		med.setAltura(med.getAltura());
		return medidaDao.save(med);
	}

	@Override
	@Transactional
	public void deleteById(Long id) {
		medidaDao.deleteById(id);
	}

}
