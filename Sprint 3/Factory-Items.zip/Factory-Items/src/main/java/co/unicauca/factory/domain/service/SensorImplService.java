package co.unicauca.factory.domain.service;

import java.util.List;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import co.unicauca.factory.adapters.rest.dao.ISensorDao;
import co.unicauca.factory.domain.entity.Sensor;
@Service
public class SensorImplService implements ISensorService {

	@Autowired
	private ISensorDao sensorDao;
	@Override
	@Transactional(readOnly = true) 
	public List<Sensor> findAll() {
		return (List<Sensor>) sensorDao.findAll();
	}

	@Override
	public Sensor findById(Long id) {
		Sensor sen = sensorDao.findById(id).orElse(null);
		return sen;
	}

	@Override
	@Transactional
	public Sensor create(Sensor sensor) {
		return sensorDao.save(sensor);
	}

	@Override
	@Transactional
	public Sensor update(Long id, Sensor sensor) {
		Sensor sen = this.findById(id);
		sen.setName(sensor.getName());
		return sensorDao.save(sen);
	}

	@Override
	@Transactional
	public void deleteById(Long id) {
		sensorDao.deleteById(id);
	}

}
