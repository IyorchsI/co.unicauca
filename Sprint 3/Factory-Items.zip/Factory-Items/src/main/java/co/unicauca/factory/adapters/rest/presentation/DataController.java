package co.unicauca.factory.adapters.rest.presentation;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import co.unicauca.factory.domain.entity.Item;
import co.unicauca.factory.domain.entity.Medida;
import co.unicauca.factory.domain.entity.Producto;
import co.unicauca.factory.domain.entity.Sensor;
import co.unicauca.factory.domain.service.IItemService;
import co.unicauca.factory.domain.service.IMedidaService;
import co.unicauca.factory.domain.service.IProductoService;
import co.unicauca.factory.domain.service.ISensorService;





@Controller
public class DataController {

	@Autowired
	private IProductoService productService;
	
	@Autowired
	private IMedidaService medidaService;
	
	
	@Autowired
	private IItemService itemService;
	
	@Autowired
	private ISensorService sensorService;
	
	@RequestMapping("/")	
	public String showPageMenu() {
		return "Menu";
	}
	@RequestMapping("/producto")	
	public String showPageProduct() {
		return "pageProd";
	}
	
	@RequestMapping("/medida")	
	public String showPageMedida() {
		return "pageMed";
	}
	
	
	@RequestMapping("/saveDataProduct")
	@ResponseBody
	public String createProduct(@RequestParam("id") Long id,@RequestParam("name") String name,@RequestParam("idItem") Long idItem){ 
	Producto product = new Producto(id,name);
	Item item = itemService.findById(idItem);
	product.setItem(item);
	productService.create(product);
	return "Creado: "+product.toString();
	}
	@RequestMapping("/updateDataProduct")
	@ResponseBody
	public String updateProduct(@RequestParam("id") Long id,@RequestParam("name") String name,@RequestParam("idItem") Long idItem){ 
	Producto product = new Producto(id,name);
	Item item = itemService.findById(idItem);
	product.setItem(item);
	productService.update(id,product);
	return "Actualizado: "+product.toString();
	}
	@RequestMapping("/findDataProduct")
	@ResponseBody
	public String findProduct(@RequestParam("id") Long id){ 
	Producto product = productService.findById(id);
	return "Encontrado: "+product.toString();
	}
	@RequestMapping("/deleteDataProduct")
	@ResponseBody
	public String deleteProduct(@RequestParam("id") Long id){ 
	productService.deleteById(id);
	return "Borrado: "+id;
	}
	
	
	@RequestMapping("/saveDataMedida")
	@ResponseBody
	public String createMedida(@RequestParam("id") Long id,@RequestParam("radio") double radio,@RequestParam("altura") double altura,@RequestParam("idItem") Long idItem,@RequestParam("idSensor") Long idSensor){ 
	String name="KICOLA: "+String.valueOf(radio)+" "+String.valueOf(altura);
	Medida medida = new Medida(id,radio,altura);
	Item item = itemService.findById(idItem);
	Sensor sensor = sensorService.findById(idSensor);
	medida.setItem(item);
	medida.setSensor(sensor);
	medidaService.create(medida);
	
	Producto product = new Producto(id,name);
	product.setItem(item);
	productService.create(product);
	return "Creado: "+medida.toString();
	}
	@RequestMapping("/updateDataMedida")
	@ResponseBody
	public String updateMedida(@RequestParam("id") Long id,@RequestParam("radio") double radio,@RequestParam("altura") double altura,@RequestParam("idItem") Long idItem,@RequestParam("idSensor") Long idSensor){ 
	Medida medida = new Medida(id,radio,altura);
	Item item = itemService.findById(idItem);
	Sensor sensor = sensorService.findById(idSensor);
	medida.setItem(item);
	medida.setSensor(sensor);
	medidaService.update(id,medida);
	return "Actualizado: "+medida.toString();
	}
	@RequestMapping("/findDataMedida")
	@ResponseBody
	public String findMedida(@RequestParam("id") Long id){ 
	Medida medida = medidaService.findById(id);
	return "Encontrado: "+medida.toString();
	}
	@RequestMapping("/deleteDataMedida")
	@ResponseBody
	public String deleteMedida(@RequestParam("id") Long id){ 
	medidaService.deleteById(id);
	return "Borrado: "+id;
	}
	
	
}
