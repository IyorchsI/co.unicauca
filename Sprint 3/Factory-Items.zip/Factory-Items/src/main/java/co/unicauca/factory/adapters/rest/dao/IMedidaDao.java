package co.unicauca.factory.adapters.rest.dao;

import org.springframework.data.repository.CrudRepository;

import co.unicauca.factory.domain.entity.Medida;

public interface IMedidaDao extends CrudRepository<Medida, Long>  {

}
