package co.unicauca.factory.domain.service;

import java.util.List;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import co.unicauca.factory.adapters.rest.dao.IItemDao;
import co.unicauca.factory.domain.entity.Item;
@Service
public class ItemImplService implements IItemService {

	@Autowired
	private IItemDao itemDao;
	@Override
	@Transactional(readOnly = true) 
	public List<Item> findAll() {
		return (List<Item>) itemDao.findAll();
	}

	@Override
	public Item findById(Long id) {
		Item sen = itemDao.findById(id).orElse(null);
		return sen;
	}

	@Override
	@Transactional
	public Item create(Item item) {
		return itemDao.save(item);
	}

	@Override
	@Transactional
	public Item update(Long id, Item item) {
		Item it = this.findById(id);
		it.setName(item.getName());
		return itemDao.save(it);
	}

	@Override
	@Transactional
	public void deleteById(Long id) {
		itemDao.deleteById(id);
	}

}
