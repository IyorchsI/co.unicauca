package co.unicauca.factory.domain.service;

import java.util.List;

import co.unicauca.factory.domain.entity.Fabrica;

public interface IFabricaService {
	public List<Fabrica> findAll();
	public Fabrica findById(Long id);
	public Fabrica create(Fabrica fabrica);
	public Fabrica update(Long id, Fabrica fabrica);
	public void deleteById(Long id);
}
