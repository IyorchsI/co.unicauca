package co.unicauca.factory.adapters.rest.dao;

import org.springframework.data.repository.CrudRepository;

import co.unicauca.factory.domain.entity.Item;

public interface IItemDao extends CrudRepository<Item, Long> {

}
