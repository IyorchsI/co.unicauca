package co.unicauca.factory.domain.service;

import java.util.List;

import co.unicauca.factory.domain.entity.Item;

public interface IItemService {
	public List<Item> findAll();
	public Item findById(Long id);
	public Item create(Item item);
	public Item update(Long id, Item item);
	public void deleteById(Long id);
}
