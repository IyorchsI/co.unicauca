package co.unicauca.factory.domain.entity;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "medidas")
public class Medida implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private double radio;
	private double altura;
	
	@ManyToOne
	@JoinColumn(name = "FK_ITEM", nullable = true, updatable = true)
	private Item Item;
	
	@ManyToOne
	@JoinColumn(name = "FK_SENSOR", nullable = true, updatable = true)
	private Sensor sensor;
	
	
	public Medida() {
	}
	
	public Medida(Long id, double radio, double altura) {
		super();
		this.id = id;
		this.radio = radio;
		this.altura = altura;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public double getRadio() {
		return radio;
	}

	public void setRadio(double radio) {
		this.radio = radio;
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	public Item getItem() {
		return Item;
	}

	public void setItem(Item item) {
		Item = item;
	}

	public Sensor getSensor() {
		return sensor;
	}

	public void setSensor(Sensor sensor) {
		this.sensor = sensor;
	}
	
	public String toString() {
		
		return " Medida: "+this.id +" "+this.radio+" "+this.altura;
	}
	
}
