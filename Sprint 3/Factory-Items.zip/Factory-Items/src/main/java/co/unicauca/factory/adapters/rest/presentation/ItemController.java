package co.unicauca.factory.adapters.rest.presentation;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;

import co.unicauca.factory.domain.entity.Item;
import co.unicauca.factory.domain.service.IItemService;




@RestController
@RequestMapping("items")
public class ItemController {
	@Autowired
	private IItemService itemService;
	/**
	* Listar todos
	*
	* @return listado de productos en json
	*/
	
	
	
	@RequestMapping(method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<Item> findAll() {
	return (List<Item>) itemService.findAll();
	}
	/**
	* Listar un producto por id
	*
	* @param id identificador
	* @return Producto en formato json
	* @throws Exception
	*/
	@RequestMapping(value = "{id}", method = RequestMethod.GET, produces =
		"application/json")
	@ResponseBody
	public Item findById(@PathVariable Long id) {
		Item item = itemService.findById(id);
	return item;
	}
	/**
	* Crear un producto
	*
	* @param product producto
	* @return producto creado
	*/
	@RequestMapping(method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public Item create(@RequestBody Item item) {
	return itemService.create(item);
	}
	/**
	* Editar
	*
	* @param product Producto a editar
	* @param id identificador del producto
	* @return producto editado
	* @throws ResourceNotFoundException recurso no encontrado
	* @throws Exception Id no encontrado
	*/
	@RequestMapping(value = "{id}", method = RequestMethod.PUT, produces =
	"application/json")
	@ResponseBody
	public Item update(@RequestBody Item item, @PathVariable Long id)
	{
	return itemService.update(id, item);
	}
	/**
	* Eliminar
	*
	* @param id id del producto
	* @throws ResourceNotFoundException id no encontrado
	*/
	@RequestMapping(value = "{id}", method = RequestMethod.DELETE, produces =
	"application/json")
	@ResponseBody
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void delete(@PathVariable Long id){
		itemService.deleteById(id);
	}
}
