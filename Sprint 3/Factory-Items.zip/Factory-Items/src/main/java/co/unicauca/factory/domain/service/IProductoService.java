package co.unicauca.factory.domain.service;

import java.util.List;

import co.unicauca.factory.domain.entity.Producto;



public interface IProductoService {
	public List<Producto> findAll();
	public Producto findById(Long id);
	public Producto create(Producto product);
	public Producto update(Long id, Producto product);
	public void deleteById(Long id);
}
