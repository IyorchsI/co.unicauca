package co.unicauca.factory.adapters.rest.presentation;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;

import co.unicauca.factory.domain.entity.Fabrica;
import co.unicauca.factory.domain.service.IFabricaService;




@RestController
@RequestMapping("fabrica")
public class FabricaController {
	@Autowired
	private IFabricaService fabricaService;
	/**
	* Listar todos
	*
	* @return listado de productos en json
	*/
	
	
	
	@RequestMapping(method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<Fabrica> findAll() {
	return (List<Fabrica>) fabricaService.findAll();
	}
	/**
	* Listar un producto por id
	*
	* @param id identificador
	* @return Producto en formato json
	* @throws Exception
	*/
	@RequestMapping(value = "{id}", method = RequestMethod.GET, produces =
		"application/json")
	@ResponseBody
	public Fabrica findById(@PathVariable Long id) {
		Fabrica fabrica = fabricaService.findById(id);
	return fabrica;
	}
	/**
	* Crear un producto
	*
	* @param product producto
	* @return producto creado
	*/
	@RequestMapping(method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public Fabrica create(@RequestBody Fabrica fabrica) {
	return fabricaService.create(fabrica);
	}
	/**
	* Editar
	*
	* @param product Producto a editar
	* @param id identificador del producto
	* @return producto editado
	* @throws ResourceNotFoundException recurso no encontrado
	* @throws Exception Id no encontrado
	*/
	@RequestMapping(value = "{id}", method = RequestMethod.PUT, produces =
	"application/json")
	@ResponseBody
	public Fabrica update(@RequestBody Fabrica fabrica, @PathVariable Long id)
	{
	return fabricaService.update(id, fabrica);
	}
	/**
	* Eliminar
	*
	* @param id id del producto
	* @throws ResourceNotFoundException id no encontrado
	*/
	@RequestMapping(value = "{id}", method = RequestMethod.DELETE, produces =
	"application/json")
	@ResponseBody
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void delete(@PathVariable Long id){
		fabricaService.deleteById(id);
	}
}
