package co.unicauca.factory.domain.service;

import java.util.List;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import co.unicauca.factory.adapters.rest.dao.IProductoDao;
import co.unicauca.factory.domain.entity.Producto;
@Service
public class ProductoImplService implements IProductoService {

	@Autowired
	private IProductoDao productDao;
	@Override
	@Transactional(readOnly = true) 
	public List<Producto> findAll() {
		return (List<Producto>) productDao.findAll();
	}

	@Override
	public Producto findById(Long id) {
		Producto prod = productDao.findById(id).orElse(null);
		return prod;
	}

	@Override
	@Transactional
	public Producto create(Producto product) {
		return productDao.save(product);
	}

	@Override
	@Transactional
	public Producto update(Long id, Producto product) {
		Producto prod = this.findById(id);
		prod.setName(product.getName());
		return productDao.save(prod);
	}

	@Override
	@Transactional
	public void deleteById(Long id) {
		productDao.deleteById(id);
	}

}
