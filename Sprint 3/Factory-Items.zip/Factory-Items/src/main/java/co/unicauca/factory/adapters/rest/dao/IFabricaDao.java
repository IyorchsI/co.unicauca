package co.unicauca.factory.adapters.rest.dao;

import org.springframework.data.repository.CrudRepository;

import co.unicauca.factory.domain.entity.Fabrica;

public interface IFabricaDao extends CrudRepository<Fabrica, Long>{

}
