package co.unicauca.factory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FactoryItemsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FactoryItemsApplication.class, args);
	}

}
