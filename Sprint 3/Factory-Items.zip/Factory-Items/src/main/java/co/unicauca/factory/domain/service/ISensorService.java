package co.unicauca.factory.domain.service;

import java.util.List;

import co.unicauca.factory.domain.entity.Sensor;

public interface ISensorService {
	public List<Sensor> findAll();
	public Sensor findById(Long id);
	public Sensor create(Sensor sensor);
	public Sensor update(Long id, Sensor sensor);
	public void deleteById(Long id);
}
