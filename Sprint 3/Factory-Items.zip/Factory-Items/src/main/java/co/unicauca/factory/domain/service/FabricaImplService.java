package co.unicauca.factory.domain.service;

import java.util.List;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import co.unicauca.factory.adapters.rest.dao.IFabricaDao;
import co.unicauca.factory.domain.entity.Fabrica;
@Service
public class FabricaImplService implements IFabricaService {

	@Autowired
	private IFabricaDao fabricaDao;
	@Override
	@Transactional(readOnly = true) 
	public List<Fabrica> findAll() {
		return (List<Fabrica>) fabricaDao.findAll();
	}

	@Override
	public Fabrica findById(Long id) {
		Fabrica fab = fabricaDao.findById(id).orElse(null);
		return fab;
	}

	@Override
	@Transactional
	public Fabrica create(Fabrica fabrica) {
		return fabricaDao.save(fabrica);
	}

	@Override
	@Transactional
	public Fabrica update(Long id, Fabrica fabrica) {
		Fabrica fab = this.findById(id);
		fab.setName(fabrica.getName());
		return fabricaDao.save(fab);
	}

	@Override
	@Transactional
	public void deleteById(Long id) {
		fabricaDao.deleteById(id);
	}

}
