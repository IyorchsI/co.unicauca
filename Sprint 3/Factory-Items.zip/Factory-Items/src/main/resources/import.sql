INSERT INTO fabrica(name) values('KICOLAFACTORY');

INSERT INTO items(name,FK_FABRICA) values('KICOLAITEM',1);	

INSERT INTO sensores(name,FK_ITEM) values('KICOLASENSOR',1);

INSERT INTO medidas(radio,altura,FK_ITEM,FK_SENSOR) values(2,5,1,1);

INSERT INTO productos(name,FK_ITEM) values('KICOLA MAX',1);