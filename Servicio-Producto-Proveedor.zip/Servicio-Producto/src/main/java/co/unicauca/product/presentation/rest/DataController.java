package co.unicauca.product.presentation.rest;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import co.unicauca.product.domain.entity.Product;
import co.unicauca.product.domain.entity.Provider;
import co.unicauca.product.domain.service.IProductService;
import co.unicauca.product.domain.service.IProviderService;

@Controller
public class DataController {
	@Autowired
	private IProductService productService;
	
	@Autowired
	private IProviderService providerService;
	
	@RequestMapping("/")	
	public String showPageMenu() {
		return "Menu";
	}
	
	@RequestMapping("/producto")	
	public String showPageProduct() {
		return "pageProd";
	}
	
	@RequestMapping("/proveedor")	
	public String showPageProvider() {
		return "pageProv";
	}
	
	@RequestMapping("/provprod")	 
	public String showPageProvProd() {
		return "pageProvProd";
	}
	
	
	@RequestMapping("/saveDataProduct")
	@ResponseBody
	public String createProduct(@RequestParam("id") Long id,@RequestParam("name") String name,@RequestParam("price") double price,@RequestParam("createAt") String date) throws ParseException { 
	Product product;
	SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
    Date registerDate = dateformat.parse(String.valueOf(date));
    product = new Product(id,name,price,registerDate);
	productService.create(product);
	return "Creado: "+product.toString();
	}
	@RequestMapping("/updateDataProduct")
	@ResponseBody
	public String updateProduct(@RequestParam("id") Long id,@RequestParam("name") String name,@RequestParam("price") double price,@RequestParam("createAt") String date) throws ParseException { 
	Product product;
	SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
    Date registerDate = dateformat.parse(String.valueOf(date));
    product = new Product(id,name,price,registerDate);
	productService.update(id,product);
	return "Actualizado: "+product.toString();
	}
	@RequestMapping("/findDataProduct")
	@ResponseBody
	public String findProduct(@RequestParam("id") Long id){ 
	Product product = productService.findById(id);
	return "Encontrado: "+product.toString();
	}
	@RequestMapping("/deleteDataProduct")
	@ResponseBody
	public String deleteProduct(@RequestParam("id") Long id){ 
	productService.deleteById(id);
	return "Borrado: "+id;
	}
	
	
	
	@RequestMapping("/saveDataProvider")
	@ResponseBody
	public String createProvider(@RequestParam("id") Long id,@RequestParam("name") String name){ 
	Provider provider = new Provider(id,name);
	providerService.create(provider);
	return "Creado: "+provider.toString();
	}
	@RequestMapping("/updateDataProvider")
	@ResponseBody
	public String updateProvider(@RequestParam("id") Long id,@RequestParam("name") String name){ 
	Provider provider = new Provider(id,name);
	providerService.update(id,provider);
	return "Actualizado: "+provider.toString();
	}
	@RequestMapping("/findDataProvider")
	@ResponseBody
	public String findProvider(@RequestParam("id") Long id){ 
	Provider provider = providerService.findById(id);
	return "Encontrado: "+provider.toString();
	}
	@RequestMapping("/deleteDataProvider")
	@ResponseBody
	public String deleteProvider(@RequestParam("id") Long id){ 
	providerService.deleteById(id);
	return "Borrado: "+id;
	}
	
	
	
	
	@RequestMapping("/saveDataProvProd")
	@ResponseBody	
	public String addProductsProvider(@RequestParam("idProvider") Long idProv,@RequestParam("idProduct") Long idProd){ 
	Product prod = productService.findById(idProd);
	Provider prov = providerService.findById(idProv);
	prod.setProvider(prov);
	productService.update(idProd, prod);
	//prov.agregarProd(prod);
	return "Asociado: "+prod.toString();
	}
	@RequestMapping("/findDataProvProd")
	@ResponseBody	
	public String findProductsProvider(@RequestParam("idProvider") Long idProv,@RequestParam("idProduct") Long idProd) throws Exception{ 
	Product prod = productService.findById(idProd);
	Provider prov = providerService.findById(idProv);
	if(!prod.getProvider().equals(prov)) {
		throw new Exception();
	}
	//prov.agregarProd(prod);
	return "Asociado: "+prod.toString();
	}
	@RequestMapping("/deleteDataProvProd")
	@ResponseBody	
	public String deleteProductsProvider(@RequestParam("idProvider") Long idProv,@RequestParam("idProduct") Long idProd) throws Exception{ 
	Product prod = productService.findById(idProd);
	Provider prov = providerService.findById(idProv);
	if(!prod.getProvider().equals(prov)) {
		throw new Exception();
	}else {
		prod.setProvider(null);
	}
	return "Eliminado: "+prod.toString();
	}
	
	
}
