package co.unicauca.product.domain.service;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import co.unicauca.product.access.dao.IProviderDao;
import co.unicauca.product.domain.entity.Provider;


@Service
public class ProviderImplService implements IProviderService {

	
	@Autowired
	private IProviderDao providerDao;

	
	
	
	@Override
	@Transactional(readOnly = true) // Para que esté sincronizada con la bd
	public List<Provider> findAll() {
	return (List<Provider>) providerDao.findAll();
	}
	/**
	* Busca un producto por su Id
	*
	* @param id identificador del producto
	* @return objeto de tipo producto
	*/
	@Override // Para que esté sincronizada con la bd
	public Provider findById(Long id) {
		Provider prov = providerDao.findById(id).orElse(null);
	return prov;
	}
	/**
	* Crea un nuevo producto
	*
	* @param product producto a crear en la bd
	* @return Producto creado
	*/
	@Override
	@Transactional
	public Provider create(Provider provider){
	return providerDao.save(provider);
	}
	/**
	* Modifica o edita un producto
	*
	* @param id, identificador del producto a modificar
	* @param product producto con los datos a editar
	* @return Producto modificado
	*/
	@Override
	@Transactional
	public Provider update(Long id, Provider provider){
	Provider prov = this.findById(id);
	prov.setName(provider.getName());
	return providerDao.save(prov);
	}
	/**
	* Eliminar producto por su id
	*
	* @param id identificador del producto a eliminar
	*/
	@Override
	@Transactional
	public void deleteById(Long id) {
	providerDao.deleteById(id);
	}
	
}
