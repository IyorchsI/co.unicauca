package co.unicauca.product.access.dao;

import org.springframework.data.repository.CrudRepository;
import co.unicauca.product.domain.entity.Provider;

public interface IProviderDao extends CrudRepository<Provider, Long>  {

}
