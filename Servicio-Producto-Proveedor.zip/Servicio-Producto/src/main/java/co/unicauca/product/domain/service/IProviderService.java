package co.unicauca.product.domain.service;

import java.util.List;
import co.unicauca.product.domain.entity.Provider;


public interface IProviderService {

	public List<Provider> findAll();
	public Provider findById(Long id);
	public Provider create(Provider product);
	public Provider update(Long id, Provider product);
	public void deleteById(Long id);
	
}
