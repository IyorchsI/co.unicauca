INSERT INTO providers(name) values('lg');
INSERT INTO providers(name) values('samsung');
INSERT INTO providers(name) values('imusa');


INSERT INTO products(name,price, create_at,FK_PROVIDER) values('tv lg Ls33-233',2600000,now(),1);
INSERT INTO products(name,price, create_at,FK_PROVIDER) values('nevera lg TLSD33-233',2200000,now(),1);
INSERT INTO products(name,price, create_at,FK_PROVIDER) values('Sound lg jks33-233',31200000,now(),1);

