/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.unicauca.deliveryfactory.infra;
import co.unicacua.rmi_commons.domain.producto.Producto;
import com.google.gson.Gson;
import java.util.Scanner;
/**
 *
 * @author JARMX
 */
public class Console implements ISubscriber{
    Runnable subscriber;// = new RabbitListener(this);
    Thread hilo;// =new Thread(subscriber);
    Scanner scanner;//new Scanner(System.in);
    //hilo.start();
    public Console(){
        scanner = new Scanner(System.in);
        subscriber = new RabbitListener(this);
        hilo = new Thread(subscriber);
    }
    public void start() {
    hilo.start();
    /*
        int option;
        do{
            System.out.println("1. Activar fabrica");
            System.out.println("2. Salir");
            option=scanner.nextInt();
            switch (option) {
                case 1:
                    subscriber.run();
                break;
            }
        }while(option != 2);
    */  
    
    }

    @Override
    public void onMessage(String msg) {
        Gson gson = new Gson();
        Producto product = gson.fromJson(msg, Producto.class);
        System.out.println("Producto: "+product.mostrarValores());
    }
}
