/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package co.unicauca.deliveryfactory.infra;

/**
 *
 * @author JARMX
 */
public interface ISubscriber {
    public void onMessage(String msg);
}
