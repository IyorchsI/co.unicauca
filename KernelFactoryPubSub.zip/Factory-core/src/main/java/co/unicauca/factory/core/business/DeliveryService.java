package co.unicauca.factory.core.business;

import co.unicacua.rmi_commons.disparador.Disparador;
import co.unicacua.rmi_commons.disparador.IDisparador;
import co.unicauca.factory.core.plugin.manager.DeliveryPluginManager;
import java.util.ArrayList;

public class DeliveryService {
    IDisparador plugin;
    public String activarFabrica(String deliveryData) throws Exception{
         
        String code = deliveryData;
         DeliveryPluginManager manager = DeliveryPluginManager.getInstance();
         plugin = manager.getDeliveryPlugin(code);
         
        if (plugin == null) {
            throw new Exception("No hay un plugin disponible para el disparador: "+ code);
        }
        return plugin.activarFabrica();
    }
    public void agregarMedicion(String deliveryData,String id, String radio, String altura) throws Exception{
         
         String code = deliveryData;
         
        if (plugin == null) {
            throw new Exception("No hay un plugin disponible para el disparador: "+ code);
        }
        plugin.agregarMedicion(id, radio, altura);
    }
    public void agregarProducto(String deliveryData,String id, String nombre) throws Exception{
         
         String code = deliveryData;
         
        if (plugin == null) {
            throw new Exception("No hay un plugin disponible para el disparador: "+ code);
        }
        plugin.agregarProducto(id, nombre);
    }
    public ArrayList<String> buscarMedida(String deliveryData,String id) throws Exception{
         
        String code = deliveryData;
        
        if (plugin == null) {
            throw new Exception("No hay un plugin disponible para el disparador: "+ code);
        }
        return plugin.buscarMedida(id);
    }
    public ArrayList<String> buscarProducto(String deliveryData,String id) throws Exception{
        
        String code = deliveryData;
         
        if (plugin == null) {
            throw new Exception("No hay un plugin disponible para el disparador: "+ code);
        }
        return plugin.buscarProducto(id);
    }
    public void eliminarMedicion(String deliveryData,String id) throws Exception{
         
        String code = deliveryData;
         
        if (plugin == null) {
            throw new Exception("No hay un plugin disponible para el disparador: "+ code);
        }
        plugin.eliminarMedicion(id);
    }
    public void eliminarProducto(String deliveryData,String id) throws Exception{
         
        String code = deliveryData;
         
        if (plugin == null) {
            throw new Exception("No hay un plugin disponible para el disparador: "+ code);
        }
        plugin.eliminarProducto(id);
    }
    public String listaProductos(String deliveryData) throws Exception{
         
        String code = deliveryData;
         
        if (plugin == null) {
            throw new Exception("No hay un plugin disponible para el disparador: "+ code);
        }
        return plugin.listaProductos();
    }
    
    
}
