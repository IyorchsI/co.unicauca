package co.unicauca.factory.core.presentation;

import co.unicauca.factory.core.business.DeliveryService;
import co.unicacua.rmi_commons.disparador.Disparador;
import co.unicacua.rmi_commons.disparador.IDisparador;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import co.unicacua.rmi_commons.disparador.IPublisher;
import co.unicauca.factory.core.infra.Publisher;
import co.unicauca.factory.core.plugin.manager.DeliveryPluginManager;
import com.google.gson.Gson;


public class Console {

    private DeliveryService deliveryService;

    private Scanner scanner;
    
    Publisher publisher;
    
    public Console(){
        deliveryService = new DeliveryService();
        scanner = new Scanner(System.in);
        publisher = new Publisher();
    }

    public void start() {

        int option;
        boolean band=false;
        System.out.println("Aplicación de envíos");

        do {

            System.out.println();
            if(!band){
            System.out.println("1. Activar fabrica");
            }
            System.out.println("2. Agregar medida");
            System.out.println("3. Agregar producto");
            System.out.println("4. Buscar medida");
            System.out.println("5 Buscar producto");
            System.out.println("6. Borrar medida");
            System.out.println("7. Borrar producto");
            System.out.println("8. Lista de productos");
            System.out.println("9. Enviar Producto.");
            System.out.println("10. Salir.");

            option = scanner.nextInt();

            switch (option) {
                case 1:
                    if(!band){
                    handleDeliveryStartFactory();
                    band=true;
                    }
                break;
                case 2:
                    handleDeliveryAddMeasuring();
                break;
                case 3:
                    handleDeliveryAddProduct();
                break;
                case 4:
                    handleDeliverySearchMeasuring();
                break;
                case 5:
                    handleDeliverySearchProduct();
                break;
                case 6:
                    handleDeliveryDeleteMeasuring();
                break;
                case 7:
                    handleDeliveryDeleteProduct();
                break;
                case 8:
                    handleDeliveryProductList();
                break;
                case 9:
                    handleDeliverySendProduct();
                break;
            }

        } while(option != 10);

        System.out.println("Aplicación terminada");
    }
    
    
    private void handleDeliverySendProduct(){
        //Creamos el objeto que será pasado a la capa de dominio para que se haga el cálculo.
        //Disparador deliveryEntity = new Disparador();
        ArrayList<String> datos;
        System.out.println("Id producto: ");
        String id = scanner.next();
        Gson gson = new Gson();
        try {

            datos=deliveryService.buscarProducto("fa", id);
            String msgJson = gson.toJson(datos.toString());
            publisher.publish(msgJson);
            System.out.println("Id: "+datos.get(0)+" Nombre: "+datos.get(1)+" Enviando...");

        } catch (Exception exception) {
            System.out.println("No fue posible activar la fabrica " + exception.getMessage());
        }
        
        }
    
    private void handleDeliveryStartFactory(){
        //Creamos el objeto que será pasado a la capa de dominio para que se haga el cálculo.
        //Disparador deliveryEntity = new Disparador();

        try {

            String fabrica = deliveryService.activarFabrica("fa");
            System.out.println("Fabrica: " + fabrica);

        } catch (Exception exception) {
            System.out.println("No fue posible activar la fabrica " + exception.getMessage());
        }

    }
    
    private void handleDeliveryAddMeasuring(){
        //Creamos el objeto que será pasado a la capa de dominio para que se haga el cálculo.
        //Disparador deliveryEntity = new Disparador();
        System.out.println("Id de la medida: ");
        String id = scanner.next();
        System.out.println("Radio de la medida: ");
        String radio = scanner.next();
        System.out.println("Altura de la medida: ");
        String altura = scanner.next();
        try {

            deliveryService.agregarMedicion("fa", id, radio, altura);
            System.out.println("Medida agregada");

        } catch (Exception exception) {
            System.out.println("No fue posible activar la fabrica " + exception.getMessage());
        }
        
        }
    private void handleDeliveryAddProduct(){
        //Creamos el objeto que será pasado a la capa de dominio para que se haga el cálculo.
        //Disparador deliveryEntity = new Disparador();
        System.out.println("Id producto: ");
        String id = scanner.next();
        System.out.println("Nombre producto: ");
        String nombre = scanner.next();
        try {

            deliveryService.agregarProducto("fa", id, nombre);
            System.out.println("Producto agregado");

        } catch (Exception exception) {
            System.out.println("No fue posible activar la fabrica " + exception.getMessage());
        }
        
        }
    private void handleDeliverySearchMeasuring(){
        //Creamos el objeto que será pasado a la capa de dominio para que se haga el cálculo.
        //Disparador deliveryEntity = new Disparador();
        ArrayList<String> datos;
        System.out.println("Id medida: ");
        String id = scanner.next();
        try {

            datos=deliveryService.buscarMedida("fa", id);
            //System.out.println("size: "+datos.size());
            System.out.println("Id: "+datos.get(0)+" Radio: "+datos.get(1)+" Altura: "+datos.get(2));

        } catch (Exception exception) {
            System.out.println("No fue posible activar la fabrica " + exception.getMessage());
        }
        
        }
    private void handleDeliverySearchProduct(){
        //Creamos el objeto que será pasado a la capa de dominio para que se haga el cálculo.
        //Disparador deliveryEntity = new Disparador();
        ArrayList<String> datos;
        System.out.println("Id producto: ");
        String id = scanner.next();
        try {

            datos=deliveryService.buscarProducto("fa", id);
            System.out.println("Id: "+datos.get(0)+" Nombre: "+datos.get(1));

        } catch (Exception exception) {
            System.out.println("No fue posible activar la fabrica " + exception.getMessage());
        }
        
        }
    private void handleDeliveryDeleteMeasuring(){
        //Creamos el objeto que será pasado a la capa de dominio para que se haga el cálculo.
        //Disparador deliveryEntity = new Disparador();
        System.out.println("Id medida: ");
        String id = scanner.next();
        try {

            deliveryService.eliminarMedicion("fa", id);
            System.out.println("Medida eliminada");

        } catch (Exception exception) {
            System.out.println("No fue posible activar la fabrica " + exception.getMessage());
        }
        
        }
    private void handleDeliveryDeleteProduct(){
        //Creamos el objeto que será pasado a la capa de dominio para que se haga el cálculo.
        //Disparador deliveryEntity = new Disparador();
        System.out.println("Id producto: ");
        String id = scanner.next();
        try {

            deliveryService.eliminarProducto("fa", id);
            System.out.println("Producto eliminado");

        } catch (Exception exception) {
            System.out.println("No fue posible activar la fabrica " + exception.getMessage());
        }
        
        }
   private void handleDeliveryProductList(){
        //Creamos el objeto que será pasado a la capa de dominio para que se haga el cálculo.
        //Disparador deliveryEntity = new Disparador();

        try {

            String fabrica = deliveryService.listaProductos("fa");
            System.out.println("Productos: " + fabrica);

        } catch (Exception exception) {
            System.out.println("No fue posible activar la fabrica " + exception.getMessage());
        }

    }

}
