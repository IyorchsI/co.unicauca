package co.unicacua.rmi_commons.domain;

import co.unicacua.rmi_commons.actuador.Actuador;
import co.unicacua.rmi_commons.actuador.IActuador;
import co.unicacua.rmi_commons.domain.producto.ProductoArray;
import co.unicacua.rmi_commons.sensor.ISensor;
import co.unicacua.rmi_commons.sensor.Sensor;

/**
 * @author Andrés Zapata 
 */
public abstract class ItemMedicion {
    private Sensor sensor;
    private Actuador actuador;
    private Medida valorReferencia;
    private Medida valorReal;
    private boolean resultado;
    private MedidaArray referencias;
    private ProductoArray productos;
    

    public ItemMedicion() {
        
    }

    public ItemMedicion(Sensor sensor, Actuador actuador, Medida valorReferencia, Medida valorReal,
            boolean resultado, MedidaArray referencias, ProductoArray productos) {
        this.sensor = sensor;
        this.actuador = actuador;
        this.valorReferencia = valorReferencia;
        this.valorReal = valorReal;
        this.resultado = resultado;
        this.referencias = referencias;
        this.productos = productos;

    }

    public Sensor getSensor() {
        return sensor;
    }

    public Actuador getActuador() {
        return actuador;
    }

    
    
    public boolean isResultado() {
        return resultado;
    }

    public void setResultado(boolean resultado) {
        this.resultado = resultado;
    }

    public MedidaArray getReferencias() {
        return referencias;
    }

    public void setReferencias(MedidaArray referencias) {
        this.referencias = referencias;
    }
    
    
    public void setSensor(Sensor sensor) {
        this.sensor = sensor;
    }

    public void setActuador(Actuador actuador) {
        this.actuador = actuador;
    }

    public Medida getValorReferencia() {
        return valorReferencia;
    }

    public Medida getValorReal() {
        return valorReal;
    }

    public ProductoArray getProductos() {
        return productos;
    }

    public void setProductos(ProductoArray productos) {
        this.productos = productos;
    }
    
    
    
    public abstract void tomarMedida();   
}
