/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.unicacua.rmi_commons.domain;

import co.unicacua.rmi_commons.actuador.Actuador;
import co.unicacua.rmi_commons.domain.producto.ProductoArray;
import co.unicacua.rmi_commons.sensor.Sensor;

/**
 *
 * @author JARMX
 */
public class ColaMedicion extends ItemMedicion {
    
    private Sensor sensor;
    private Actuador actuador;
    private Medida valorReferencia;
    private Medida valorReal;
    private boolean resultado;
    private MedidaArray referencias;
    private ProductoArray productos;

    public ColaMedicion() {
    
    }

    public ColaMedicion(Sensor sensor, Actuador actuador, Medida valorReferencia, Medida valorReal,
            boolean resultado, MedidaArray referencias, ProductoArray producto) {
        super(sensor, actuador, valorReferencia, valorReal, resultado, referencias, producto);
        this.sensor = sensor;
        this.actuador = actuador;
        this.valorReferencia = valorReferencia;
        this.valorReal = valorReal;
        this.resultado = resultado;
        this.referencias = referencias;
        this.productos = producto;
    }
  
    
    public Sensor getSensor() {
        return sensor;
    }

    public void setSensor(Sensor sensor) {
        this.sensor = sensor;
    }

    public Actuador getActuador() {
        return actuador;
    }

    public void setActuador(Actuador actuador) {
        this.actuador = actuador;
    }

    public Medida getValorReferencia() {
        return valorReferencia;
    }

    public void setValorReferencia(Medida valorReferencia) {
        this.valorReferencia = valorReferencia;
    }

    public Medida getValorReal() {
        return valorReal;
    }

    public void setValorReal(Medida valorReal) {
        this.valorReal = valorReal;
    }

    public boolean isResultado() {
        return resultado;
    }

    public void setResultado(boolean resultado) {
        this.resultado = resultado;
    }

    public MedidaArray getReferencias() {
        return referencias;
    }

    public void setReferencias(MedidaArray referencias) {
        this.referencias = referencias;
    }

    public ProductoArray getProductos() {
        return productos;
    }

    public void setProductos(ProductoArray productos) {
        this.productos = productos;
    }

    @Override
    public void tomarMedida(){
        if(referencias.getIngresadas().isEmpty()){
        valorReal = sensor.tomarMedida(this);
        resultado = valorReal.getId().contentEquals(valorReferencia.getId());
        actuador.agregarProductos(productos, valorReal);   
        }else{
            sensor.tomarMedidas(this);
        }
        
    } 

    
    
}
