/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.unicacua.rmi_commons.domain;

import java.util.ArrayList;

/**
 *
 * @author JARMX
 */
public interface IMedidaArray {
    Medida comparar(Medida valorReferencia);
    void adicionar(String id, String radio, String altura);
    ArrayList<String> buscar (String id);
    void eliminar(String id);
}
