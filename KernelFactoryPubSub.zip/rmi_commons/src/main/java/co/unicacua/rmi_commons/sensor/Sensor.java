/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.unicacua.rmi_commons.sensor;

import co.unicacua.rmi_commons.domain.ColaMedicion;
import co.unicacua.rmi_commons.domain.ItemMedicion;
import co.unicacua.rmi_commons.domain.Medida;
import co.unicacua.rmi_commons.domain.MedidaArray;


/**
 *
 * @author JARMX
 */
public class Sensor implements ISensor {
    
    private String id;
    private String nombre;

    public Sensor() {
    }

    
    
    public Sensor(String id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }
    
    
    @Override
    public Medida tomarMedida(ItemMedicion item) {
        return item.getReferencias().comparar(item.getValorReferencia());
    }

    @Override
    public void tomarMedidas(ItemMedicion item) {
        Medida real=null;
        Medida ingresada=null;
        int last = item.getReferencias().getIngresadas().size()-1;
            ingresada=item.getReferencias().getIngresadas().get(last);
            real=item.getReferencias().comparar(ingresada);
            item.getActuador().agregarProductos(item.getProductos(), real);
        /*for(int i=0;i<item.getReferencias().getIngresadas().size();i++){
            ingresada=item.getReferencias().getIngresadas().get(i);
            real=item.getReferencias().comparar(ingresada);
            item.getActuador().agregarProductos(item.getProductos(), real);
        }*/
    }


    
}
