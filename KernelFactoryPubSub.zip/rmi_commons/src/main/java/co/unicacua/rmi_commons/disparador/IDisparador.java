/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.unicacua.rmi_commons.disparador;;
import java.util.ArrayList;
/**
 *
 * @author JARMX
 */
public interface IDisparador{
    public String activarFabrica();
    public String listaProductos();
    public void agregarMedicion(String id,String radio,String altura);
    public void agregarProducto(String id,String nombre);
    public ArrayList<String> buscarMedida(String id);
    public ArrayList<String> buscarProducto(String id);
    public void eliminarMedicion(String id);
    public void eliminarProducto(String id);
    
    
    
}
