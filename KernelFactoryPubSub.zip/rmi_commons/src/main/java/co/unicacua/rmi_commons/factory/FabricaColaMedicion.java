/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.unicacua.rmi_commons.factory;

import co.unicacua.rmi_commons.actuador.Actuador;
import co.unicacua.rmi_commons.domain.ColaMedicion;
import co.unicacua.rmi_commons.domain.ItemMedicion;
import co.unicacua.rmi_commons.domain.Medida;
import co.unicacua.rmi_commons.domain.MedidaArray;
import co.unicacua.rmi_commons.domain.producto.ProductoArray;
import co.unicacua.rmi_commons.sensor.Sensor;

/**
 *
 * @author JARMX
 */
public class FabricaColaMedicion extends FabricaItemMedicion {

    @Override
    public ItemMedicion crearItemMedicion() {
       ItemMedicion item = new ColaMedicion(new Sensor("s1","sensorcola"),new Actuador(),new Medida("m1","2.5","15"),
            new Medida(),false,new MedidaArray(),new ProductoArray());
       item.tomarMedida();
       return item;
    }
    
}
