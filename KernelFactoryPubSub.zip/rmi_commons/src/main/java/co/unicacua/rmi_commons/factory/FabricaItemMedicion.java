package co.unicacua.rmi_commons.factory;

import co.unicacua.rmi_commons.domain.ColaMedicion;
import co.unicacua.rmi_commons.domain.ItemMedicion;
/**
 * @author Andrés Zapata 
 */
public abstract class FabricaItemMedicion {
    public abstract ItemMedicion crearItemMedicion();
}
