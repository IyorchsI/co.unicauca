/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.unicauca.factory.plugin;

import co.unicacua.rmi_commons.disparador.IDisparador;
import co.unicacua.rmi_commons.disparador.Disparador;
import java.util.ArrayList;


/**
 *
 * @author JARMX
 */
public class FactoryPlugin implements IDisparador {
    
    private Disparador fabrica = new Disparador();

    @Override
    public String activarFabrica() {
    return "fabrica activada: "+fabrica.activarFabrica();
    }

    @Override
    public void agregarMedicion(String id, String radio, String altura) {
        fabrica.agregarMedicion(id, radio, altura);
    }

    @Override
    public void agregarProducto(String id, String nombre) {
        fabrica.agregarProducto(id, nombre);
    }

    @Override
    public ArrayList<String> buscarMedida(String id) {
        return fabrica.buscarMedida(id);
    }

    @Override
    public ArrayList<String> buscarProducto(String id) {
        return fabrica.buscarProducto(id);
    }

    @Override
    public void eliminarMedicion(String id) {
        fabrica.eliminarMedicion(id);
    }

    @Override
    public void eliminarProducto(String id) {
        fabrica.eliminarProducto(id);
    }

    @Override
    public String listaProductos() {
        return fabrica.listaProductos();
    }
    
    
    
}
