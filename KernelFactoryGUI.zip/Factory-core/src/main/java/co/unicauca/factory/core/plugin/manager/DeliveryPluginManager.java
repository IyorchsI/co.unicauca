package co.unicauca.factory.core.plugin.manager;

import co.unicacua.rmi_commons.disparador.IDisparador;
import co.unicacua.rmi_commons.disparador.IPublisher;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.net.URLDecoder;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Esta clase es una fábrica que utiliza reflexión para crear dinámicamente los
 * plugins.
 *
 */
public class DeliveryPluginManager {

    private static final String FILE_NAME = "plugin.properties";
    private static DeliveryPluginManager instance;

    private Properties pluginProperties;

    private DeliveryPluginManager() {
        pluginProperties = new Properties();
    }

    public static DeliveryPluginManager getInstance() {
        return instance;
    }

    public static void init(String basePath) throws Exception {

        instance = new DeliveryPluginManager();
        instance.loadProperties(basePath);
        if (instance.pluginProperties.isEmpty()) {
            throw new Exception("Could not initialize plugins");
        }

    }

    public IDisparador getDeliveryPlugin(String countryCode) {

        //Verificar si existe una entrada en el archivo para el país indicado.
        String propertyName = "delivery." + countryCode.toLowerCase();
        System.out.println("name: "+propertyName);
        if (!pluginProperties.containsKey(propertyName)) {
            return null;
        }

        IDisparador plugin = null;
        //Obtener el nombre de la clase del plugin.
        String pluginClassName = pluginProperties.getProperty(propertyName);

        try {

            //Obtener una referencia al tipo de la clase del plugin.
            Class<?> pluginClass = Class.forName(pluginClassName);
            if (pluginClass != null) {

                //Crear un nuevo objeto del plugin.
                Object pluginObject = pluginClass.getDeclaredConstructor().newInstance();

                if (pluginObject instanceof IDisparador) {
                    plugin = (IDisparador) pluginObject;
                }
            }

        } catch (ClassNotFoundException | IllegalAccessException | IllegalArgumentException | InstantiationException | NoSuchMethodException | SecurityException | InvocationTargetException ex) {
            Logger.getLogger("DeliveryPluginManager").log(Level.SEVERE, "Error al ejecutar la aplicación", ex);
        }

        return plugin;

    }

    private Object getAnyObject(String classNameProperty) {
        System.out.println("Class Property. "+classNameProperty);
        if (!pluginProperties.containsKey(classNameProperty)) {
            return null;
        }

        Object plugin = null;
        //Obtener el nombre de la clase del plugin.
        String pluginClassName = pluginProperties.getProperty(classNameProperty);
        System.out.println(pluginClassName);

        try {

            //Obtener una referencia al tipo de la clase del plugin.
            Class<?> pluginClass = Class.forName(pluginClassName);
            if (pluginClass != null) {
                //Crear un nuevo objeto del plugin.
                plugin = pluginClass.getDeclaredConstructor().newInstance();
            }

        } catch (ClassNotFoundException | IllegalAccessException | IllegalArgumentException | InstantiationException | NoSuchMethodException | SecurityException | InvocationTargetException ex) {
            Logger.getLogger("PluginManager").log(Level.SEVERE, "Error al ejecutar la aplicación", ex);
        }
        return plugin;
    }
    
    public IPublisher getPublisherPlugin(String propertyTechPublisher) {
        System.out.println("Property Tech. "+propertyTechPublisher);
        IPublisher plugin = null;
        Object pluginObject= getAnyObject(propertyTechPublisher);
        if (pluginObject instanceof IPublisher) {
                    plugin = (IPublisher) pluginObject;
        }
        plugin.setProperties(pluginProperties);
        return plugin;
    }
    
    private void loadProperties(String basePath) {

       try {
            String filePath = basePath+FILE_NAME;
            filePath = URLDecoder.decode(filePath, "UTF-8");
            try (FileInputStream stream = new FileInputStream(filePath)) {
                
                pluginProperties.load(stream);
                
            } catch (IOException ex) {
                Logger.getLogger("DeliveryPluginManager").log(Level.SEVERE, "Error al ejecutar la aplicación", ex);
            }            
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(DeliveryPluginManager.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
