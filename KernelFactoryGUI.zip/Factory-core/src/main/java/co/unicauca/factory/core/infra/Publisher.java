/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.unicauca.factory.core.infra;
import co.unicacua.rmi_commons.disparador.IPublisher;
import co.unicauca.factory.core.plugin.manager.DeliveryPluginManager;
import java.util.Properties;
/**
 *
 * @author JARMX
 */
public class Publisher{
    public Publisher() {
    }
    public void publish(String msg){
        System.out.println("Publish msg. "+msg);
        DeliveryPluginManager manager = DeliveryPluginManager.getInstance();
        IPublisher publisher = manager.getPublisherPlugin("publisherTech"); 
        publisher.publish(msg);
    }

}
