/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.unicacua.rmi_commons.domain.producto;

import java.util.ArrayList;

/**
 *
 * @author JARMX
 */
public interface IProductoArray {
    
    public void adicionarProductos(String id, String nombre);
    public ArrayList<String> buscarProductos(String id);
    public void eliminarProductos(String id);
    public String mostrarProductos();
    
}
