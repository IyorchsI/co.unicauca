/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.unicacua.rmi_commons.disparador;

import co.unicacua.rmi_commons.domain.ItemMedicion;
import co.unicacua.rmi_commons.domain.Medida;
import co.unicacua.rmi_commons.factory.FabricaColaMedicion;
import co.unicacua.rmi_commons.factory.FabricaItemMedicion;
import java.util.ArrayList;

/**
 *
 * @author JARMX
 */
public class Disparador implements IDisparador {
    private FabricaItemMedicion fabrica;
    private ItemMedicion item;
    public Disparador(){
    super();
    fabrica = new FabricaColaMedicion();
    item = fabrica.crearItemMedicion();
    }

    @Override
    public String activarFabrica(){
        return " Estado ON";
    }

    @Override
    public void agregarMedicion(String id, String radio, String altura) {
        item.getReferencias().adicionar(id, radio, altura);
        item.tomarMedida();
    }

    @Override
    public void agregarProducto(String id, String nombre) {
        item.getProductos().adicionarProductos(id, nombre);
    }

    @Override
    public ArrayList<String> buscarMedida(String id) {
    return item.getReferencias().buscar(id);
    }

    @Override
    public ArrayList<String> buscarProducto(String id) {
    return item.getProductos().buscarProductos(id);
    }

    @Override
    public void eliminarMedicion(String id) {
        item.getReferencias().eliminar(id);
    }

    @Override
    public void eliminarProducto(String id) {
        item.getProductos().eliminarProductos(id);
    }

    @Override
    public String listaProductos() {
        return "Lista productos: "+item.getProductos().mostrarProductos();
    }
    
}
