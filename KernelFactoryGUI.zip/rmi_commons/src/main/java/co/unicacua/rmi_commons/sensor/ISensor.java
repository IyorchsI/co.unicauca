package co.unicacua.rmi_commons.sensor;

import co.unicacua.rmi_commons.domain.ColaMedicion;
import co.unicacua.rmi_commons.domain.ItemMedicion;
import co.unicacua.rmi_commons.domain.Medida;
import co.unicacua.rmi_commons.domain.MedidaArray;

/**
 * @author Andrés Zapata
 */
public interface ISensor {
    Medida tomarMedida(ItemMedicion item);
    void tomarMedidas(ItemMedicion item);
}
