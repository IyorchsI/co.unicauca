/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.unicacua.rmi_commons.domain;

/**
 *
 * @author JARMX
 */
public class Medida {
    
    private String id;
    private String radio;
    private String altura;

    public Medida() {
    
    }

    
    
    public Medida(String id, String radio, String altura) {
        this.id = id;
        this.radio = radio;
        this.altura = altura;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRadio() {
        return radio;
    }

    public void setRadio(String radio) {
        this.radio = radio;
    }

    public String getAltura() {
        return altura;
    }

    public void setAltura(String altura) {
        this.altura = altura;
    }

    
    
}
