/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.unicacua.rmi_commons.actuador;

import co.unicacua.rmi_commons.domain.Medida;
import co.unicacua.rmi_commons.domain.producto.ProductoArray;

/**
 *
 * @author JARMX
 */
public class Actuador implements IActuador {

    @Override
    public void agregarProductos(ProductoArray productos, Medida valorReal) {
        productos.adicionarProductos(valorReal.getId(), " Altura: "+valorReal.getAltura()+" Radio: "+valorReal.getRadio());
    }


    
}
