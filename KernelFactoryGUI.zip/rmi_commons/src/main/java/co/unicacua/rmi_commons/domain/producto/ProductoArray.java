/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.unicacua.rmi_commons.domain.producto;

import java.util.ArrayList;

/**
 *
 * @author JARMX
 */
public class ProductoArray implements IProductoArray{
    
    private static ArrayList<Producto> productos;
    private String Marca;

    public ProductoArray() {
        Marca="Kicola";
        if(productos == null){
            productos = new ArrayList();
            initProductos();
        }
    }

    public void setMarca(String Marca) {
        this.Marca = Marca;
    }

    public static ArrayList<Producto> getProductos() {
        return productos;
    }
    
    private void initProductos(){
        productos.add(new Producto("01",Marca+"Lite"));
        productos.add(new Producto("02",Marca));
        productos.add(new Producto("03",Marca+"EX"));
    }

    @Override
    public void adicionarProductos(String id,String nombre) {
        productos.add(new Producto(id,Marca+nombre));
    }

    @Override
    public ArrayList<String> buscarProductos(String id) {
       ArrayList<String> datos = new ArrayList();
       for(int i=0; i<productos.size();i++){
           if(productos.get(i).getId().contentEquals(id)){
               datos.add(productos.get(i).getId());
               datos.add(productos.get(i).getNombre());
               datos.add(String.valueOf(i));
               break;
           }
       }
       return datos;
    }

    @Override
    public String mostrarProductos() {
        String cadenas = "";
        for(int i=0; i<productos.size();i++){
           cadenas+="\n"+productos.get(i).mostrarValores()+"\n";
        }
        return cadenas;
    }

    @Override
    public void eliminarProductos(String id) {
        int i=0;
        ArrayList<String> datos = buscarProductos(id);
        if(datos!=null){
        i=Integer.parseInt(datos.get(2));
        productos.remove(i);
        }
    }
    
}
