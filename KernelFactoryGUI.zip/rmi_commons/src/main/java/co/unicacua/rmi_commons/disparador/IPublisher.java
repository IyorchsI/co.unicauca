/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package co.unicacua.rmi_commons.disparador;
import java.util.Properties;
/**
 *
 * @author JARMX
 */
public interface IPublisher {
    public void publish(String msg);
    public void setProperties(Properties publisherProperties);
}
