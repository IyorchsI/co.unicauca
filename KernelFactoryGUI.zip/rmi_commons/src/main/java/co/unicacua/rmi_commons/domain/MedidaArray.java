/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.unicacua.rmi_commons.domain;

import java.util.ArrayList;

/**
 *
 * @author JARMX
 */
public class MedidaArray implements IMedidaArray{
    ArrayList<Medida> referencias;
    ArrayList<Medida> ingresadas;

    public MedidaArray() {
        if(referencias==null){
        referencias = new ArrayList();
        initMedida();
        }
        if(ingresadas==null){
            ingresadas = new ArrayList();
        }
    }
    
    private void initMedida(){
        referencias.add(new Medida("m1","2.5","15"));
        referencias.add(new Medida("m2","2.3","17"));
        referencias.add(new Medida("m3","2.0","14"));
        referencias.add(new Medida("m4","1.7","13"));
    }

    public ArrayList<Medida> getIngresadas() {
        return ingresadas;
    }

    public void setIngresadas(ArrayList<Medida> ingresadas) {
        this.ingresadas = ingresadas;
    }

    
    
    @Override
    public Medida comparar(Medida valorReferencia) {
        Medida valor=valorReferencia;
        for(int i=0; i<referencias.size();i++){
            if(referencias.get(i).getAltura().contentEquals(valorReferencia.getAltura())
                    && referencias.get(i).getRadio().contentEquals(valorReferencia.getRadio())){
                valor=referencias.get(i);
            }else{
                referencias.add(valorReferencia);
            }
        }
        return valor;
    }

    @Override
    public void adicionar(String id, String radio, String altura) {
        ingresadas.add(new Medida(id,radio,altura));
    }

    @Override
    public ArrayList<String> buscar(String id) {
        ArrayList<String> datos = new ArrayList();
        for(int i=0; i<ingresadas.size();i++){
            if(ingresadas.get(i).getId().contentEquals(id)){
                datos.add(ingresadas.get(i).getId());
                datos.add(ingresadas.get(i).getRadio());
                datos.add(ingresadas.get(i).getAltura());
                datos.add(String.valueOf(i));
                break;
            }
        }
        return datos;
    }

    @Override
    public void eliminar(String id) {
        int i=0;
        ArrayList<String> datos = buscar(id);
        if(datos!=null){
        i=Integer.parseInt(datos.get(3));
        ingresadas.remove(i);
        }
    }

    
    
    
}
