/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.unicauca.deliveryfactory.infra;

/**
 *
 * @author JARMX
 */
public class ApplicationS {
    public static void main(String[] args)  {
            //Console presentationObject = new Console();
            //presentationObject.start();
            frmMainS gui = new frmMainS();
            gui.setVisible(true);
    }
}
